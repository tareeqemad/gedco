<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteConfig extends Model
{
    protected $table = 'site_configs';

    protected $fillable = ['key','value'];

    public static function get(string $key, $default = null) {
        $row = static::where('key',$key)->first();
        return $row?->value ?? $default;
    }

    public static function set(string $key, $value): void {
        static::updateOrCreate(['key'=>$key], ['value'=>$value]);
    }
}
