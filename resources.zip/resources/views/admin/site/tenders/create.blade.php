{{-- resources/views/admin/site/tenders/create.blade.php --}}
@extends('layouts.admin')
@section('title', __('admin.tenders.create_title'))

@section('content')
    <div class="container-fluid p-0">
        <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
            <div class="card-header bg-white border-bottom py-2 px-3 d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-1">
                    <i class="bi bi-plus-circle text-primary fs-6"></i>
                    <h6 class="mb-0 fw-semibold text-dark-emphasis">{{ __('admin.tenders.create_title') }}</h6>
                </div>
                <a href="{{ route('admin.tenders.index') }}" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-arrow-left me-1"></i> {{ __('admin.tenders.back_to_list') }}
                </a>
            </div>
        </div>

        <form id="tenderForm" action="{{ route('admin.tenders.store') }}" method="POST" novalidate>
            @csrf

            <div class="row g-4">
                <div class="col-lg-5">
                    <div class="card border-0 shadow-sm rounded-3 bg-white">
                        <div class="card-body p-4 row g-3">

                            <div class="col-md-4">
                                <label class="form-label">{{ __('admin.tenders.form_mnews_id') }}</label>
                                <input type="number" name="mnews_id" class="form-control @error('mnews_id') is-invalid @enderror"
                                       value="{{ old('mnews_id') }}" placeholder="{{ __('admin.tenders.form_example_number') }}">
                                @error('mnews_id')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>

                            <div class="col-md-8">
                                <label class="form-label">{{ __('admin.tenders.form_column_name_1') }}</label>
                                <input type="text" name="column_name_1" class="form-control @error('column_name_1') is-invalid @enderror"
                                       value="{{ old('column_name_1') }}" placeholder="{{ __('admin.tenders.form_column_placeholder') }}">
                                @error('column_name_1')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">{{ __('admin.tenders.form_the_date_1') }} <span class="text-muted">{{ __('admin.tenders.form_date_text') }}</span></label>
                                <input type="text" name="the_date_1" class="form-control @error('the_date_1') is-invalid @enderror"
                                       value="{{ old('the_date_1') }}" placeholder="{{ __('admin.tenders.form_example_date') }}">
                                @error('the_date_1')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">{{ __('admin.tenders.form_coulm_serial') }}</label>
                                <input type="number" name="coulm_serial" class="form-control @error('coulm_serial') is-invalid @enderror"
                                       value="{{ old('coulm_serial') }}" placeholder="{{ __('admin.tenders.form_example_number') }}">
                                @error('coulm_serial')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">{{ __('admin.tenders.form_event_1') }}</label>
                                <input type="text" name="event_1" class="form-control @error('event_1') is-invalid @enderror"
                                       value="{{ old('event_1') }}" placeholder="{{ __('admin.tenders.form_event_placeholder') }}">
                                @error('event_1')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">{{ __('admin.tenders.form_the_user_1') }}</label>
                                <input type="text" name="the_user_1" class="form-control @error('the_user_1') is-invalid @enderror"
                                       value="{{ old('the_user_1') }}" placeholder="{{ __('admin.tenders.form_example_user') }}">
                                @error('the_user_1')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-7">
                    {{-- OLD_VALUE_1 --}}
                    <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
                        <div class="card-header bg-white border-bottom py-2 px-3 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-1">
                                <i class="bi bi-file-text text-secondary"></i>
                                <span class="fw-semibold">{{ __('admin.tenders.form_old_value') }}</span>
                            </div>
                            <small class="text-muted">{{ __('admin.tenders.form_html_supported') }}</small>
                        </div>
                        <div class="card-body p-3">
                            <div class="quill-shell border rounded-3 shadow-sm">
                                <div id="toolbar-old" class="ql-toolbar ql-snow">
                                    <span class="ql-formats"><select class="ql-header"></select></span>
                                    <span class="ql-formats">
                                        <button class="ql-bold"></button>
                                        <button class="ql-italic"></button>
                                        <button class="ql-underline"></button>
                                        <button class="ql-link"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-list" value="ordered"></button>
                                        <button class="ql-list" value="bullet"></button>
                                        <select class="ql-align"></select>
                                        <button class="ql-clean"></button>
                                    </span>
                                </div>
                                <div id="editor-old" class="ql-container ql-snow"></div>
                            </div>
                            <textarea name="old_value_1" id="old_value_1" class="d-none">{{ old('old_value_1') }}</textarea>
                            @error('old_value_1')<div class="invalid-feedback d-block mt-2">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    {{-- NEW_VALUE_1 --}}
                    <div class="card border-0 shadow-sm rounded-3 bg-white">
                        <div class="card-header bg-white border-bottom py-2 px-3 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-1">
                                <i class="bi bi-file-text text-success"></i>
                                <span class="fw-semibold">{{ __('admin.tenders.form_new_value') }}</span>
                            </div>
                            <small class="text-muted">{{ __('admin.tenders.form_html_supported') }}</small>
                        </div>
                        <div class="card-body p-3">
                            <div class="quill-shell border rounded-3 shadow-sm">
                                <div id="toolbar-new" class="ql-toolbar ql-snow">
                                    <span class="ql-formats"><select class="ql-header"></select></span>
                                    <span class="ql-formats">
                                        <button class="ql-bold"></button>
                                        <button class="ql-italic"></button>
                                        <button class="ql-underline"></button>
                                        <button class="ql-link"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-list" value="ordered"></button>
                                        <button class="ql-list" value="bullet"></button>
                                        <select class="ql-align"></select>
                                        <button class="ql-clean"></button>
                                    </span>
                                </div>
                                <div id="editor-new" class="ql-container ql-snow"></div>
                            </div>
                            <textarea name="new_value_1" id="new_value_1" class="d-none">{{ old('new_value_1') }}</textarea>
                            @error('new_value_1')<div class="invalid-feedback d-block mt-2">{{ $message }}</div>@enderror
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex gap-2 justify-content-end mt-4">
                <button type="submit" class="btn btn-primary px-4">
                    <i class="bi bi-check me-1"></i> {{ __('admin.tenders.form_save') }}
                </button>
                <a href="{{ route('admin.tenders.index') }}" class="btn btn-light px-4">{{ __('admin.tenders.form_cancel') }}</a>
            </div>
        </form>
    </div>
@endsection

@push('styles')
    {{-- نفس أسلوب الاستدعاء المستخدم عندك --}}
    <link rel="stylesheet" href="{{ asset('assets/admin/libs/quill/quill.snow.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/admin/libs/quill/quill.bubble.css') }}">
@endpush

@push('scripts')
    <script src="{{ asset('assets/admin/libs/quill/quill.min.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const commonModules = id => ({
                toolbar: { container: id },
                history: { delay: 400, maxStack: 100, userOnly: true }
            });

            // OLD editor
            const qOld = new Quill('#editor-old', {
                theme: 'snow',
                modules: commonModules('#toolbar-old'),
                placeholder: '{{ __('admin.tenders.form_old_value_placeholder') }}'
            });

            // NEW editor
            const qNew = new Quill('#editor-new', {
                theme: 'snow',
                modules: commonModules('#toolbar-new'),
                placeholder: '{{ __('admin.tenders.form_new_value_placeholder') }}'
            });

            // preload from old()
            const oldHidden = document.getElementById('old_value_1');
            const newHidden = document.getElementById('new_value_1');
            if (oldHidden.value) qOld.root.innerHTML = oldHidden.value;
            if (newHidden.value) qNew.root.innerHTML = newHidden.value;

            // on submit → dump HTML to hidden fields
            document.getElementById('tenderForm').addEventListener('submit', function () {
                oldHidden.value = qOld.root.innerHTML.trim();
                newHidden.value = qNew.root.innerHTML.trim();
            });
        });
    </script>
@endpush
