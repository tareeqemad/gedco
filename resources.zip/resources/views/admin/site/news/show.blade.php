@extends('layouts.admin')
@section('title', __('admin.news.show_title') . ' #' . $item->id)

@section('content')
    @php
        $breadcrumbTitle = __('admin.news.show_title') . ' #' . $item->id;
        $breadcrumbParent = __('admin.menu.news');
        $breadcrumbParentUrl = route('admin.news.index');
        $published = $item->is_published ?? (($item->status ?? 'published') === 'published');
        $publishedAt = optional($item->published_at)->format('Y-m-d') ?? '—';
        $coverUrl = $item->cover_url;
        $pdfUrl = $item->pdf_url;
    @endphp

    <div class="container-fluid p-0">
        <!-- Header -->
        <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
            <div class="card-header bg-white border-bottom py-2 px-3 d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-newspaper text-primary fs-5"></i>
                    <h6 class="mb-0 fw-semibold text-dark-emphasis">{{ __('admin.news.show_title') }} #{{ $item->id }}</h6>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <a href="{{ route('admin.news.index') }}" class="btn btn-light btn-sm">
                        <i class="bi bi-arrow-left"></i> {{ __('admin.news.back') }}
                    </a>
                    @can('news.edit')
                        <a href="{{ route('admin.news.edit', $item) }}" class="btn btn-warning btn-sm">
                            <i class="bi bi-pencil-square"></i> {{ __('admin.news.edit_news') }}
                        </a>
                    @endcan
                    @can('news.delete')
                        <button type="button" id="btnDelete" class="btn btn-outline-danger btn-sm">
                            <i class="bi bi-trash"></i> {{ __('admin.news.delete') }}
                        </button>
                    @endcan
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Main content -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-3 bg-white">
                    <div class="card-body p-4">
                        <!-- Title + meta -->
                        <div class="mb-3">
                            <h4 class="fw-bold mb-2">{{ $item->title }}</h4>
                            <div class="d-flex flex-wrap align-items-center gap-2 small text-muted">
                                <span class="d-inline-flex align-items-center gap-1">
                                    <i class="bi bi-calendar"></i>
                                    {{ $publishedAt !== '—' ? \Carbon\Carbon::parse($publishedAt)->locale('ar')->translatedFormat('d F Y') : '—' }}
                                </span>
                                <span>•</span>
                                <span class="d-inline-flex align-items-center gap-1">
                                    <i class="bi bi-eye"></i>
                                    الحالة:
                                    <span class="badge {{ $published ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' }}">
                                        {{ $published ? 'منشور' : 'مسودة' }}
                                    </span>
                                </span>
                                @if($item->featured)
                                    <span>•</span>
                                    <span class="d-inline-flex align-items-center gap-1">
                                        <i class="bi bi-star-fill text-warning"></i> مميّز
                                    </span>
                                @endif
                                <span class="ms-auto d-none d-md-inline text-xxs">
                                    آخر تحديث: {{ optional($item->updated_at)->format('Y-m-d H:i') ?? '—' }}
                                </span>
                            </div>
                        </div>

                        <!-- Tabs -->
                        <ul class="nav nav-tabs nav-tabs-sm border-0 mb-3" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active px-3 py-1" data-bs-toggle="tab" data-bs-target="#tab-html">
                                    <i class="bi bi-file-earmark-text me-1"></i> المحتوى (HTML)
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link px-3 py-1" data-bs-toggle="tab" data-bs-target="#tab-text">
                                    <i class="bi bi-file-text me-1"></i> نص مجرد
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link px-3 py-1" data-bs-toggle="tab" data-bs-target="#tab-preview">
                                    <i class="bi bi-eye me-1"></i> معاينة مقال
                                </button>
                            </li>
                        </ul>

                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tab-html">
                                <div class="article-html border rounded-3 p-3" style="direction: rtl; text-align: right; line-height:1.9; font-size: 0.98rem;">
                                    {!! $item->body !!}
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab-text">
                                <pre class="border rounded-3 p-3" style="white-space: pre-wrap; word-break: break-word; min-height: 220px;">
{{ strip_tags($item->body ?? '') }}</pre>
                            </div>
                            <div class="tab-pane fade" id="tab-preview">
                                <article class="rounded-3 border p-3">
                                    @if($coverUrl)
                                        <img src="{{ $coverUrl }}" class="rounded-3 w-100 mb-3" style="max-height:360px; object-fit:cover;" alt="cover">
                                    @endif
                                    <h3 class="fw-bold mb-2">{{ $item->title }}</h3>
                                    <div class="small text-muted mb-3 d-flex align-items-center gap-2">
                                        <i class="bi bi-calendar"></i>
                                        <span>{{ $publishedAt !== '—' ? \Carbon\Carbon::parse($publishedAt)->locale('ar')->translatedFormat('d F Y') : '—' }}</span>
                                    </div>
                                    <div class="lh-lg" style="direction: rtl; text-align: right;">
                                        {!! $item->body !!}
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar meta -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-3 bg-white mb-3">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <i class="bi bi-info-circle text-primary"></i>
                            <h6 class="mb-0 fw-semibold">البيانات</h6>
                        </div>
                        <div class="list-group list-group-flush small">
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">ID</span>
                                <span>{{ $item->id }}</span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">الحالة</span>
                                <span class="badge {{ $published ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' }}">
                                    {{ $published ? 'منشور' : 'مسودة' }}
                                </span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">تاريخ النشر</span>
                                <span>{{ $publishedAt }}</span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">مميّز</span>
                                <span>{!! $item->featured ? '<i class="bi bi-check text-success"></i>' : '<i class="bi bi-x text-danger"></i>' !!}</span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">أُنشئ</span>
                                <span>{{ optional($item->created_at)->format('Y-m-d H:i') ?? '—' }}</span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">آخر تحديث</span>
                                <span>{{ optional($item->updated_at)->format('Y-m-d H:i') ?? '—' }}</span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">أضاف</span>
                                <span>{{ $item->creator?->name ?? 'غير معروف' }}</span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span class="text-muted">عدّل</span>
                                <span>{{ $item->updater?->name ?? 'غير معروف' }}</span>
                            </div>
                        </div>
                    </div>
                </div>

                @if($pdfUrl)
                    <div class="card border-0 shadow-sm rounded-3 bg-white">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center gap-2 mb-2">
                                <i class="bi bi-file-pdf text-danger"></i>
                                <h6 class="mb-0 fw-semibold">المرفق</h6>
                            </div>
                            <a href="{{ $pdfUrl }}" class="btn btn-outline-primary w-100" target="_blank">
                                <i class="bi bi-eye"></i> فتح PDF
                            </a>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <link rel="stylesheet" href="{{ asset('assets/admin/libs/sweetalert2/sweetalert2.min.css') }}">
@endpush

@push('scripts')
    <script src="{{ asset('assets/admin/libs/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const btnDelete = document.getElementById('btnDelete');
            if (!btnDelete) return;

            btnDelete.addEventListener('click', function () {
                Swal.fire({
                    title: 'تأكيد الحذف',
                    text: 'هل تريد حذف هذا الخبر نهائياً؟ لا يمكن التراجع!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'نعم، احذف',
                    cancelButtonText: 'إلغاء',
                    reverseButtons: true,
                    buttonsStyling: false,
                    customClass: {
                        confirmButton: 'btn btn-danger px-4',
                        cancelButton: 'btn btn-secondary px-4 me-2'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        fetch('{{ route('admin.news.destroy', $item) }}', {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json'
                            }
                        })
                            .then(r => r.json())
                            .then(data => {
                                if (data.success) {
                                    Swal.fire('تم!', data.message, 'success').then(() => {
                                        window.location.href = '{{ route('admin.news.index') }}';
                                    });
                                } else {
                                    Swal.fire('خطأ', data.message || 'فشل الحذف', 'error');
                                }
                            })
                            .catch(() => {
                                Swal.fire('خطأ', 'حدث خطأ في الاتصال', 'error');
                            });
                    }
                });
            });
        });
    </script>
@endpush
