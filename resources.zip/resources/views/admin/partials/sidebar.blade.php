<aside class="app-sidebar sticky" id="sidebar">
    <!-- Start::main-sidebar-header -->
    <div class="main-sidebar-header">
        <a href="{{ route('admin.dashboard') }}" class="header-logo">
            <img src="{{ asset('assets/admin/images/brand-logos/logo_white.webp') }}" alt="logo" class="desktop-logo">
            <img src="{{ asset('assets/admin/images/brand-logos/toggle-logo.png') }}" alt="logo" class="toggle-logo">
            <img src="{{ asset('assets/admin/images/brand-logos/logo_dark.webp') }}" alt="logo" class="desktop-dark">
            <img src="{{ asset('assets/admin/images/brand-logos/toggle-dark.png') }}" alt="logo" class="toggle-dark">
            <img src="{{ asset('assets/admin/images/brand-logos/logo_white.webp') }}" alt="logo" class="desktop-white">
            <img src="{{ asset('assets/admin/images/brand-logos/toggle-white.png') }}" alt="logo" class="toggle-white">
        </a>
    </div>
    <!-- End::main-sidebar-header -->

    <!-- Start::main-sidebar -->
    <div class="main-sidebar" id="sidebar-scroll">
        <nav class="main-menu-container nav nav-pills flex-column sub-open">

            <div class="slide-left" id="slide-left">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path>
                </svg>
            </div>

            @php
                $isActive = fn($routes) => request()->routeIs($routes) ? 'active' : '';
                $isOpen   = fn($routes) => request()->routeIs($routes) ? 'open'   : '';
                $show     = fn($routes) => request()->routeIs($routes) ? 'display:block' : '';
            @endphp

            <ul class="main-menu">

                <!-- 1) Dashboard -->
                <li class="slide {{ $isActive('admin.dashboard') }}">
                    <a href="{{ route('admin.dashboard') }}" class="side-menu__item">
                        <i class="bi bi-house-door side-menu__icon"></i>
                        <span class="side-menu__label">{{ __('admin.menu.dashboard') }}</span>
                    </a>
                </li>

                <!-- 2) Users -->
                @can('users.view')
                    <li class="slide has-sub {{ $isOpen('admin.users.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.users.*') }}">
                            <i class="bi bi-people side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.users') }}</span>
                            <i class="fe fe-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.users.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.users.index') }}" class="side-menu__item {{ $isActive('admin.users.index') }}">
                                    {{ __('admin.menu.users_list') }}
                                </a>
                            </li>
                            @can('users.create')
                                <li class="slide">
                                    <a href="{{ route('admin.users.create') }}" class="side-menu__item {{ $isActive('admin.users.create') }}">
                                        {{ __('admin.menu.add_user') }}
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan

                <!-- 3) Content Management -->
                <li class="slide__category">
                    <span class="side-menu__label text-muted text-xs opacity-70">{{ __('admin.menu.content_management') }}</span>
                </li>

                @can('sliders.view')
                    <li class="slide {{ $isActive('admin.sliders.*') }}">
                        <a href="{{ route('admin.sliders.index') }}" class="side-menu__item">
                            <i class="bi bi-images side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.slider') }}</span>
                        </a>
                    </li>
                @endcan

                @can('about.view')
                    <li class="slide {{ $isActive('admin.about.*') }}">
                        <a href="{{ route('admin.about.index') }}" class="side-menu__item">
                            <i class="bi bi-info-circle side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.about_us') }}</span>
                        </a>
                    </li>
                @endcan

                @can('why.view')
                    <li class="slide {{ $isActive('admin.why.*') }}">
                        <a href="{{ route('admin.why.index') }}" class="side-menu__item">
                            <i class="bi bi-lightning-charge side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.why_choose_us') }}</span>
                        </a>
                    </li>
                @endcan

                <!-- News -->
                @can('news.view')
                    <li class="slide has-sub {{ $isOpen('admin.news.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.news.*') }}">
                            <i class="bi bi-newspaper side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.news') }}</span>
                            <i class="fe fe-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.news.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.news.index') }}"
                                   class="side-menu__item {{ $isActive('admin.news.index') }}">
                                    {{ __('admin.menu.news_list') }}
                                </a>
                            </li>
                            @can('news.create')
                                <li class="slide">
                                    <a href="{{ route('admin.news.create') }}"
                                       class="side-menu__item {{ $isActive('admin.news.create') }}">
                                        {{ __('admin.menu.add_news') }}
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan

                <!-- Tenders -->
                @can('tenders.view')
                    <li class="slide has-sub {{ $isOpen('admin.tenders.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.tenders.*') }}">
                            <i class="bi bi-file-earmark-text side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.tenders') }}</span>
                            <i class="fe fe-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.tenders.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.tenders.index') }}"
                                   class="side-menu__item {{ $isActive('admin.tenders.index') }}">
                                    {{ __('admin.menu.tenders_list') }}
                                </a>
                            </li>
                            @can('tenders.create')
                                <li class="slide">
                                    <a href="{{ route('admin.tenders.create') }}"
                                       class="side-menu__item {{ $isActive('admin.tenders.create') }}">
                                        {{ __('admin.menu.add_tender') }}
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan

                <!-- Advertisements & Jobs -->
                @can('advertisements.view')
                    <li class="slide has-sub {{ $isOpen('admin.advertisements.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.advertisements.*') }}">
                            <i class="bi bi-megaphone side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.advertisements_jobs') }}</span>
                            <i class="fe fe-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.advertisements.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.advertisements.index') }}"
                                   class="side-menu__item {{ $isActive('admin.advertisements.index') }}">
                                    {{ __('admin.menu.advertisements_list') }}
                                </a>
                            </li>
                            @can('advertisements.create')
                                <li class="slide">
                                    <a href="{{ route('admin.advertisements.create') }}"
                                       class="side-menu__item {{ $isActive('admin.advertisements.create') }}">
                                        {{ __('admin.menu.add_advertisement') }}
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan

                @can('impact-stats.view')
                    <li class="slide has-sub {{ $isOpen('admin.impact-stats.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.impact-stats.*') }}">
                            <i class="bi bi-graph-up-arrow side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.statistics') }}</span>
                            <i class="fe fe-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.impact-stats.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.impact-stats.index') }}"
                                   class="side-menu__item {{ $isActive('admin.impact-stats.index') }}">
                                    {{ __('admin.menu.statistics_list') }}
                                </a>
                            </li>
                        </ul>
                    </li>
                @endcan

                @can('staff-profiles.view')
                    <li class="slide {{ $isActive('admin.staff-profiles.*') }}">
                        <a href="{{ route('admin.staff-profiles.index') }}" class="side-menu__item">
                            <i class="bi bi-person-lines-fill side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.employee_forms') }}</span>
                        </a>
                    </li>
                @endcan

                <!-- 4) Site Settings -->
                <li class="slide__category mt-3">
                    <span class="side-menu__label text-muted text-xs opacity-70">{{ __('admin.menu.site_settings') }}</span>
                </li>

                <li class="slide {{ $isActive('admin.site-settings.*') }}">
                    <a href="{{ route('admin.site-settings.edit', 1) }}" class="side-menu__item">
                        <i class="bi bi-gear side-menu__icon"></i>
                        <span class="side-menu__label">{{ __('admin.menu.general_settings') }}</span>
                    </a>
                </li>

                @can('home-video.edit')
                    <li class="slide {{ $isActive('admin.homeVideo.*') }}">
                        <a href="{{ route('admin.homeVideo.edit') }}" class="side-menu__item {{ $isActive('admin.homeVideo.*') }}">
                            <i class="bi bi-camera-video side-menu__icon"></i>
                            <span class="side-menu__label">{{ __('admin.menu.homepage_video') }}</span>
                        </a>
                    </li>
                @endcan

                <!-- 5) System Management (Super Admin Only) -->
                @role('super-admin')
                <li class="slide__category mt-3">
                    <span class="side-menu__label text-muted text-xs opacity-70">{{ __('admin.menu.system_management') }}</span>
                </li>

                <li class="slide has-sub {{ $isOpen('admin.social-links.*') }}">
                    <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.social-links.*') }}">
                        <i class="bi bi-share side-menu__icon"></i>
                        <span class="side-menu__label">{{ __('admin.menu.social_links') }}</span>
                        <i class="fe fe-chevron-left side-menu__angle"></i>
                    </a>
                    <ul class="slide-menu child1" style="{{ $show('admin.social-links.*') }}">
                        <li class="slide">
                            <a href="{{ route('admin.social-links.index') }}" class="side-menu__item {{ $isActive('admin.social-links.index') }}">
                                {{ __('admin.menu.social_links_list') }}
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('admin.social-links.create') }}" class="side-menu__item {{ $isActive('admin.social-links.create') }}">
                                {{ __('admin.menu.add_social_link') }}
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="slide {{ $isActive('admin.permissions.*') }}">
                    <a href="{{ route('admin.permissions.index') }}" class="side-menu__item">
                        <i class="bi bi-shield-lock side-menu__icon"></i>
                        <span class="side-menu__label">{{ __('admin.menu.permissions') }}</span>
                    </a>
                </li>

                <li class="slide has-sub {{ $isOpen('admin.roles.*') }}">
                    <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.roles.*') }}">
                        <i class="bi bi-person-badge side-menu__icon"></i>
                        <span class="side-menu__label">{{ __('admin.menu.roles') }}</span>
                        <i class="fe fe-chevron-left side-menu__angle"></i>
                    </a>
                    <ul class="slide-menu child1" style="{{ $show('admin.roles.*') }}">
                        <li class="slide">
                            <a href="{{ route('admin.roles.index') }}" class="side-menu__item {{ $isActive('admin.roles.index') }}">
                                {{ __('admin.menu.roles_list') }}
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('admin.roles.create') }}" class="side-menu__item {{ $isActive('admin.roles.create') }}">
                                {{ __('admin.menu.add_role') }}
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Activity Logs (سجل الأنشطة) -->
                <li class="slide has-sub {{ $isOpen('admin.activity-logs.*') }}">
                    <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.activity-logs.*') }}">
                        <i class="bi bi-activity side-menu__icon"></i>
                        <span class="side-menu__label">سجل الأنشطة</span>
                        <i class="fe fe-chevron-left side-menu__angle"></i>
                    </a>
                    <ul class="slide-menu child1" style="{{ $show('admin.activity-logs.*') }}">
                        <li class="slide">
                            <a href="{{ route('admin.activity-logs.index') }}" class="side-menu__item {{ $isActive('admin.activity-logs.index') }}">
                                جميع الأنشطة
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('admin.activity-logs.active-users') }}" class="side-menu__item {{ $isActive('admin.activity-logs.active-users') }}">
                                المستخدمون المتصلون
                            </a>
                        </li>
                    </ul>
                </li>

                @endrole

            </ul>

            <div class="slide-right" id="slide-right">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path>
                </svg>
            </div>

        </nav>
    </div>
</aside>
