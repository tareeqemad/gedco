<!DOCTYPE html>
<html lang="en" dir="{{ $direction ?? 'rtl' }}" data-nav-layout="vertical" data-theme-mode="light" data-header-styles="color" data-menu-styles="color"	 data-toggled="close">

<head>

    <!-- Meta Data -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title','لوحة التحكم')</title>

    <!-- Favicon -->
    <link rel="icon" href="{{ asset('assets/admin/images/brand-logos/favicon.ico') }}" type="image/x-icon">

    <!-- Choices JS -->
    <script src="{{ asset('assets/admin/libs/choices.js/public/assets/scripts/choices.min.js') }}"></script>

    <!-- Main Theme Js -->
    <script src="{{ asset('assets/admin/js/main.js') }}"></script>

    <!-- Bootstrap Css -->
    <link id="bootstrap-style" href="{{ asset('assets/admin/libs/bootstrap/css/bootstrap' . (($direction ?? 'rtl') === 'rtl' ? '.rtl' : '') . '.min.css') }}" rel="stylesheet" >

    <!-- Style Css -->
    <link href="{{ asset('assets/admin/css/styles.min.css') }}" rel="stylesheet" >

    <!-- Icons Css -->
    <link href="{{ asset('assets/admin/css/icons.css') }}" rel="stylesheet" >

    <!-- Node Waves Css -->
    <link href="{{ asset('assets/admin/libs/node-waves/waves.min.css') }}" rel="stylesheet" >

    <!-- Simplebar Css -->
    <link href="{{ asset('assets/admin/libs/simplebar/simplebar.min.css') }}" rel="stylesheet" >

    <!-- Color Picker Css -->
    <link rel="stylesheet" href="{{ asset('assets/admin/libs/flatpickr/flatpickr.min.css') }}">

    <!-- Choices Css -->
    <link rel="stylesheet" href="{{ asset('assets/admin/libs/choices.js/public/assets/styles/choices.min.css') }}">

    <link rel="stylesheet" href="{{ asset('assets/admin/css/custom.css') }}">
    @stack('styles')
</head>

<body>



<!-- Loader -->
<div id="loader" >
    <img src="{{ asset('assets/admin/images/media/loader.svg') }}" alt="">
</div>
<!-- Loader -->

<div class="page">
    <!-- app-header -->
    @include('admin.partials.header')
    <!-- /app-header -->
    <!-- Start::app-sidebar -->
    @include('admin.partials.sidebar')
    <!-- End::app-sidebar -->

    <!-- main-content -->
    <div class="main-content app-content">

        <!-- container -->
        <div class="main-container container-fluid">

            <!-- breadcrumb -->
            @include('admin.partials.breadcrumb', [
                'title' => $breadcrumbTitle ?? '',
                'parent' => $breadcrumbParent ?? null,
                'parent_url' => $breadcrumbParentUrl ?? null
            ])

            <!-- /breadcrumb -->

            <!-- Flash Messages -->
            @include('admin.partials.flash-messages')

            @yield('content')

        </div>
        <!-- Container closed -->
    </div>
    <!-- main-content closed -->


    <!-- Footer Start -->
    @include('admin.partials.footer')
    <!-- Footer End -->



</div>


<!-- Scroll To Top -->
<div class="scrollToTop">
    <span class="arrow"><i class="bi bi-arrow-up fs-20"></i></span>
</div>
<div id="responsive-overlay"></div>
<!-- Scroll To Top -->

<!-- Popper JS -->
<script src="{{ asset('assets/admin/libs/@popperjs/core/umd/popper.min.js') }}"></script>

<!-- Bootstrap JS -->
<script src="{{ asset('assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

<!-- Defaultmenu JS -->
<script src="{{ asset('assets/admin/js/defaultmenu.min.js') }}"></script>

<!-- Node Waves JS-->
<script src="{{ asset('assets/admin/libs/node-waves/waves.min.js') }}"></script>

<!-- Sticky JS -->
<script src="{{ asset('assets/admin/js/sticky.js') }}"></script>




<!-- Custom JS -->
<script src="{{ asset('assets/admin/js/custom.js') }}"></script>
<script src="{{ asset('assets/admin/js/notifications.js') }}"></script>
@vite(['resources/js/app.js'])


@stack('scripts')
</body>

</html>
